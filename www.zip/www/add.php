<html>
<body>

Number1:<?php echo $_GET["number1"]; ?><br>
Number2:<?php echo $_GET["number2"]; ?><br>
This is your total <?php echo $_GET["name"] ; ?>:<?php
$x=$_GET["number1"];
$y=$_GET["number2"];
function add($x,$y)
{
    $total=$x+$y;
    return $total;
}
 
echo add($x,$y);
?>

</body>
</html>