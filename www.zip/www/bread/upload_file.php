<!DOCTYPE html>
<html lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="icon" href="img/fav-icon.png" type="image/x-icon" />
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Cake - Bakery</title>

        <!-- Icon css link -->
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="vendors/linearicons/style.css" rel="stylesheet">
        <link href="vendors/flat-icon/flaticon.css" rel="stylesheet">
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        
        <!-- Rev slider css -->
        <link href="vendors/revolution/css/settings.css" rel="stylesheet">
        <link href="vendors/revolution/css/layers.css" rel="stylesheet">
        <link href="vendors/revolution/css/navigation.css" rel="stylesheet">
        <link href="vendors/animate-css/animate.css" rel="stylesheet">
        
        <!-- Extra plugin css -->
        <link href="vendors/owl-carousel/owl.carousel.min.css" rel="stylesheet">
        
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

  <!--================Main Header Area =================-->
  <header class="main_header_area">
			<div class="top_header_area row m0">
				<div class="container">
					<div class="float-left">
						<a href="tell:+18004567890"><i class="fa fa-phone" aria-hidden="true"></i> + (1800) 456 7890</a>
						<a href="mainto:info@cakebakery.com"><i class="fa fa-envelope-o" aria-hidden="true"></i> info@lucasloaves.com.au</a>
					</div>
					<div class="float-right">
						<ul class="h_social list_style">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						</ul>
						<ul class="h_search list_style">
							<li class="shop_cart"><a href="#"><i class="lnr lnr-cart"></i></a></li>
							<li><a class="popup-with-zoom-anim" href="#test-search"><i class="fa fa-search"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
        
	</header>
		
        <!--================End Main Header Area =================-->
        
        <!--================End Main Header Area =================-->
        <section class="banner_area">
        	<div class="container">
        		<div class="banner_text">
        			<h3>Careers</h3>
        			<ul>
        				<li><a href="#">Home</a></li>
        				<li><a href="#">Careers</a></li>
        			</ul>
        		</div>
        	</div>
        </section>
        <!--================End Main Header Area =================-->

<h2>First name: <?php echo $_POST["fname"]; ?><br></h2>
<h2>Last name: <?php echo $_POST["lname"]; ?><br></h2>
<h2>Email Address:<?php echo $_POST["email"]; ?><br></h2>
<h2>Text:<?php echo $_POST["message"]; ?><br><br></h2>
<?php
$allowedExts = array("pdf", "doc");
$temp = explode(".", $_FILES["file1"]["name"]);
$extension = end($temp);

if (($_FILES["file1"]["type"] == "application/pdf")
|| ($_FILES["file1"]["type"] == "application/doc")
&& ($_FILES["file1"]["size"] < 200000)
&& in_array($extension, $allowedExts))
  {
  if ($_FILES["file1"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file1"]["error"] . "<br>";
    }
  else
    {
    echo "<h2>Upload: " . $_FILES["file1"]["name"] . "<br></h2>";
    echo "<h2>Temp file: " . $_FILES["file1"]["tmp_name"] . "<br><h2>";

    if (file_exists("upload/" . $_FILES["file1"]["name"]))
      {
      echo $_FILES["file1"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file1"]["tmp_name"],
      "upload/" . $_FILES["file1"]["name"]);
  echo "Stored in: " . "upload/" . $_FILES["file1"]["name"];
      }
    }
  }
else
  {
  echo "Invalid file";
  }
?>
<?php
$allowedExts = array("pdf", "doc");
$temp = explode(".", $_FILES["file1"]["name"]);
$extension = end($temp);

if (($_FILES["file2"]["type"] == "application/pdf")
|| ($_FILES["file2"]["type"] == "application/doc")
&& ($_FILES["file2"]["size"] < 200000)
&& in_array($extension, $allowedExts))
  {
  if ($_FILES["file2"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file2"]["error"] . "<br>";
    }
  else
    {
    echo "<br><br>Upload: " . $_FILES["file2"]["name"] . "<br>";
    echo "Temp file: " . $_FILES["file2"]["tmp_name"] . "<br>";

    if (file_exists("upload/" . $_FILES["file2"]["name"]))
      {
      echo $_FILES["file2"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file2"]["tmp_name"],
      "upload/" . $_FILES["file2"]["name"]);
  echo "Stored in: " . "upload/" . $_FILES["file2"]["name"];
      }
    }
  }
else
  {
  echo "Invalid file";
  }
  echo "<br><a class='pink_btn' href='http://192.168.5.41/bread/upload.html'>Back</a>";
?>
  </body>
 </html>
